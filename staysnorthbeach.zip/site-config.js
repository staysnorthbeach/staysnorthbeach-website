window.NBPS_CONFIG = {

  // ─── BRAND ────────────────────────────────────────────────────────────────
  brand:   "Stays North Beach",
  domain:  "staysnorthbeach.com.au",
  address: "37 Kitchener Street, North Beach WA 6020",
  contactName: "Mel",

  // ─── GUESTY BOOKING ENGINE ────────────────────────────────────────────────
  // Step 1: In Guesty → Booking Engine → Create Engine for NBPS-01 and NBPS-02
  // Step 2: Paste the Booking Engine URL below
  // Step 3: If using the embedded calendar, paste the embed URL below
  bookingEngineUrl:      "",   // e.g. "https://booking.guesty.com/...your-engine-url..."
  bookingEngineEmbedUrl: "",   // e.g. "https://booking.guesty.com/...embed..."

  // Per-property booking URLs (optional — use if Guesty gives you separate URLs)
  midnightBookingUrl:  "",
  frontBookingUrl:     "",
  combinedBookingUrl:  "",

  // ─── AIRBNB LISTING URLS ──────────────────────────────────────────────────
  // Paste the direct Airbnb listing URLs for each property.
  // These appear as secondary "Also on Airbnb" links in the booking section.
  airbnbMidnightUrl: "",   // e.g. "https://www.airbnb.com.au/rooms/XXXXXXXXX"
  airbnbFrontUrl:    "",   // e.g. "https://www.airbnb.com.au/rooms/XXXXXXXXX"

  // ─── SOCIAL MEDIA ─────────────────────────────────────────────────────────
  // Paste the full URL to each page/profile once it is live.
  instagramUrl: "",   // e.g. "https://www.instagram.com/staysnorthbeach"
  facebookUrl:  "",   // e.g. "https://www.facebook.com/staysnorthbeach"
  linkedinUrl:  "",   // e.g. "https://www.linkedin.com/company/staysnorthbeach"
  tiktokUrl:    "",   // e.g. "https://www.tiktok.com/@staysnorthbeach"

  // ─── GUIDE URLS ───────────────────────────────────────────────────────────
  guideMidnightUrl: "guide/midnight.html",
  guideFrontUrl:    "guide/front.html",
  guideCombinedUrl: "guide/combined.html",

  // ─── LAUNCH CONTROL ───────────────────────────────────────────────────────
  // Set to FALSE before going live. Hides the review banner.
  previewMode: true

};
