# Stays North Beach — Hosting, Go-Live & Calendar Integration Guide

Your current setup: **Airbnb + PriceLabs**. This guide is written for that stack. It covers getting the website live immediately using your Airbnb listing links, then connecting a live calendar once you choose a channel manager.

---

## Part 1 — Register Your Domain

Register **staysnorthbeach.com.au** if you haven't already.

**Recommended registrar:** [Crazy Domains](https://www.crazydomains.com.au) or [Netfleet](https://www.netfleet.com.au)

1. Search `staysnorthbeach.com.au` — costs roughly $15–$25/year
2. At checkout, tick "Owner/Operator of an Australian business" for the .com.au eligibility check
3. Complete purchase. Leave DNS settings alone for now — you'll update them in Part 3.

---

## Part 2 — Host the Website on Netlify (Free)

1. Go to [netlify.com](https://www.netlify.com) → sign up (Google login is easiest)
2. Click **Add new site** → **Deploy manually**
3. Drag your entire website folder into the upload area:
   `Desktop → Airbnb Back Unit → NBPS_Direct_Booking_Website_v2`
4. Netlify deploys in ~30 seconds and gives you a URL like `hungry-fox-123.netlify.app`
5. Rename it: **Site configuration** → **Change site name** → set to `staysnorthbeach`
   Your URL becomes `staysnorthbeach.netlify.app`

---

## Part 3 — Connect Your Domain to Netlify

1. In Netlify → **Domain management** → **Add a domain** → enter `staysnorthbeach.com.au`
2. Netlify shows you two nameserver addresses (e.g. `dns1.p01.nsone.net`) — copy them
3. Log in to Crazy Domains → **My Domains** → your domain → **DNS / Nameservers** → **Change Nameservers**
4. Replace the existing nameservers with Netlify's two nameservers → Save
5. DNS propagation takes 15 minutes to 48 hours
6. Once done, Netlify automatically issues a free SSL certificate — you'll see a green padlock at `https://www.staysnorthbeach.com.au`

---

## Part 4 — Booking Calendar: Your Options

You're on Airbnb + PriceLabs. Here's how the website calendar works with each approach.

---

### Option A — Airbnb Listing Links Only (Free, Available Today)

The simplest setup. Your website shows "Book on Airbnb" buttons that take guests straight to your Airbnb listing. No live calendar embed — guests see availability on Airbnb itself.

**How to set it up:**

1. Log in to Airbnb → go to your **Midnight Hideaway** listing
2. Click **View listing** in your browser — copy the URL (e.g. `https://www.airbnb.com.au/rooms/12345678`)
3. Repeat for the **Front Residence**
4. Open `site-config.js` in your website folder and paste:
   ```js
   airbnbMidnightUrl: "https://www.airbnb.com.au/rooms/XXXXXXXX",
   airbnbFrontUrl:    "https://www.airbnb.com.au/rooms/XXXXXXXX",
   ```
5. Save `site-config.js` → re-upload the folder to Netlify

The website will now show "Book on Airbnb" buttons. This works immediately while you decide on a channel manager.

---

### Option B — Smoobu (Recommended, ~€29/month)

Best fit for a 2-property operator. Smoobu syncs directly with Airbnb in real time, works natively with PriceLabs, and gives you an embeddable booking calendar for your website. When a guest books on Airbnb, those dates block on your website instantly — and vice versa.

**How to set it up:**

1. Go to [smoobu.com](https://www.smoobu.com) → sign up for a trial
2. Add your two properties: **The Midnight Hideaway** and **Front Residence**
3. Connect Airbnb: **Settings** → **Channel manager** → **Airbnb** → **Connect**
   - Log in with your Airbnb host account
   - Map each Smoobu property to the matching Airbnb listing
   - Smoobu imports your existing bookings and syncs from this point forward
4. Connect PriceLabs: **Settings** → **Integrations** → **PriceLabs** → connect
   - Your PriceLabs pricing rules will continue to apply automatically
5. Create a booking widget: **Website** → **Booking widget** → configure and copy the embed code
   - Or grab the direct Booking Engine URL
6. Paste into `site-config.js`:
   ```js
   bookingEngineUrl:      "https://login.smoobu.com/...your-booking-url...",
   bookingEngineEmbedUrl: "",   // paste embed URL here if using inline calendar
   ```
7. Save `site-config.js` → re-upload to Netlify

---

### Option C — Hostaway (~$100+/month)

Better choice if you plan to expand to Booking.com, Vrbo, or manage 5+ properties. More powerful reporting and automation. Also integrates natively with PriceLabs.

**How to set it up:**

1. Go to [hostaway.com](https://www.hostaway.com) → book a demo / sign up
2. Add properties, connect Airbnb under **Channel Manager** → **Airbnb**
3. Connect PriceLabs under **Integrations**
4. Go to **Direct bookings** → **Booking engine** → copy the booking engine URL
5. Paste into `site-config.js`:
   ```js
   bookingEngineUrl: "https://...hostaway-booking-engine-url...",
   ```
6. Save and re-upload to Netlify

---

### Smoobu vs Hostaway — Quick Comparison

| | Smoobu | Hostaway |
|---|---|---|
| Price | ~€29/month | ~$100+/month |
| Best for | 1–5 properties, simplicity | 5+ properties, growth |
| Airbnb sync | ✓ Real-time | ✓ Real-time |
| PriceLabs | ✓ Native integration | ✓ Native integration |
| Booking.com / Vrbo | ✓ | ✓ |
| Setup difficulty | Easy | Moderate |
| Support | Good | Good |

**Recommendation for your situation:** Start with Smoobu. If you add more properties or platforms in future, Hostaway is an easy upgrade path.

---

## Part 5 — Airbnb iCal Sync (If Using Smoobu or Hostaway)

When you connect Airbnb to Smoobu or Hostaway, they handle the full two-way sync automatically — you don't need to manually set up iCal feeds. The channel manager does it for you when you connect Airbnb under their channel manager settings.

---

## Part 6 — Per-Property Booking URLs (Optional)

If your channel manager gives you separate booking URLs for each property, you can wire those up too:

```js
midnightBookingUrl:  "https://...booking-url-for-midnight...",
frontBookingUrl:     "https://...booking-url-for-front...",
combinedBookingUrl:  "https://...booking-url-for-both...",
```

If you only have one combined URL, just paste it into `bookingEngineUrl` and leave the per-property fields blank.

---

## Part 7 — Connect Social Media

Once your social pages are live, open `site-config.js` and paste each URL. The website shows or hides buttons based on which fields are filled in.

```js
instagramUrl: "https://www.instagram.com/staysnorthbeach",
facebookUrl:  "https://www.facebook.com/staysnorthbeach",
linkedinUrl:  "https://www.linkedin.com/company/staysnorthbeach",
tiktokUrl:    "https://www.tiktok.com/@staysnorthbeach",
```

**Setting up each platform:**

**Instagram** — Create a Business account at instagram.com, username `staysnorthbeach`, add website (`staysnorthbeach.com.au`) and contact details.

**Facebook** — Create a Page at facebook.com → **For Business** → category: Holiday rental.

**LinkedIn** — Create a Company Page at linkedin.com → type: Small Business → add website.

**TikTok** — Create a Business Account, username `staysnorthbeach`. Short clips of the fire pit, kitchen, and courtyard perform very well.

---

## Part 8 — Go-Live Checklist

Work through this before removing the preview banner.

- [ ] Domain registered and pointing to Netlify (loads at `https://www.staysnorthbeach.com.au`)
- [ ] SSL certificate active (green padlock in browser)
- [ ] Airbnb listing URLs filled in `site-config.js` — even if no channel manager yet
- [ ] (Optional) Smoobu / Hostaway connected and `bookingEngineUrl` filled in
- [ ] Test a date search on the website
- [ ] At least one social media page live and URL filled in
- [ ] All property photos display correctly — check on your phone
- [ ] Guest guide pages ready (`guide/midnight.html`, `guide/front.html`)

**When all ticked:**
1. Open `site-config.js`
2. Change `previewMode: true` → `previewMode: false`
3. Save → re-upload the folder to Netlify
4. The preview banner disappears. You're live.

---

## Part 9 — Re-deploying After Any Change

1. Edit any file in your website folder
2. Go to Netlify → **Deploys** tab → drag the whole folder into the deploy area
3. Live in under 30 seconds

---

## Part 10 — Google Search Console (After Going Live)

1. Go to [search.google.com/search-console](https://search.google.com/search-console)
2. Add property → enter `https://www.staysnorthbeach.com.au`
3. Verify ownership (Netlify → Site configuration → Custom headers → add the verification meta tag)
4. Submit sitemap: `https://www.staysnorthbeach.com.au/sitemap.xml`

Also set up a **Google Business Profile** at [business.google.com](https://business.google.com) — category: Vacation Home Rental. This gets you into Google Maps and local search.

---

## Quick Reference — Key Files

| File | What it controls | Edit when... |
|------|-----------------|-------------|
| `site-config.js` | All URLs and social links | Adding booking engine, Airbnb links, social pages, going live |
| `index.html` | Website content | Changing text, adding photos |
| `styles.css` | Visual design | Changing layout or colours |
| `script.js` | Booking logic | Rarely — only if changing booking flow |
| `sitemap.xml` | Google page index | Adding new pages |

---

## Help & Support

- **Netlify docs:** [docs.netlify.com](https://docs.netlify.com)
- **Smoobu support:** [smoobu.com/help](https://www.smoobu.com/help)
- **Hostaway support:** [hostaway.com/support](https://www.hostaway.com/support)
- **PriceLabs support:** [pricelabs.co/support](https://pricelabs.co/support)
- **Google Search Console:** [support.google.com/webmasters](https://support.google.com/webmasters)

---

*Guide prepared for Stays North Beach — staysnorthbeach.com.au*
*Current setup: Airbnb + PriceLabs*
