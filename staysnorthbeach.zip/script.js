(() => {
  const config = window.NBPS_CONFIG || {};

  // ─── PREVIEW BANNER ────────────────────────────────────────────────────────
  const previewBanner = document.getElementById('previewBanner');
  if (config.previewMode) previewBanner.hidden = false;

  // ─── DATE PICKER DEFAULTS ──────────────────────────────────────────────────
  const today    = new Date();
  const iso      = d => d.toISOString().split('T')[0];
  const checkin  = document.getElementById('checkin');
  const checkout = document.getElementById('checkout');

  checkin.min   = iso(today);
  const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
  checkin.value  = iso(tomorrow);
  const dayAfter = new Date(today); dayAfter.setDate(dayAfter.getDate() + 3);
  checkout.min   = iso(dayAfter);
  checkout.value = iso(dayAfter);

  checkin.addEventListener('change', () => {
    const d = new Date(checkin.value + 'T00:00:00');
    d.setDate(d.getDate() + 1);
    checkout.min = iso(d);
    if (!checkout.value || checkout.value <= checkin.value) checkout.value = iso(d);
  });

  // ─── BOOKING URLS ──────────────────────────────────────────────────────────
  const bookingUrls = {
    midnight: config.midnightBookingUrl || config.bookingEngineUrl || '',
    front:    config.frontBookingUrl    || config.bookingEngineUrl || '',
    combined: config.combinedBookingUrl || config.bookingEngineUrl || '',
    all:      config.bookingEngineUrl   || ''
  };

  // ─── DIALOG SETUP ──────────────────────────────────────────────────────────
  const dialog    = document.getElementById('bookingDialog');
  const closeBtn  = dialog.querySelector('.dialog-close');
  const setupNote = document.getElementById('bookingSetupNote');

  const linkMap = {
    midnight: document.getElementById('bookMidnight'),
    front:    document.getElementById('bookFront'),
    combined: document.getElementById('bookCombined')
  };

  Object.entries(linkMap).forEach(([type, el]) => {
    const url = bookingUrls[type];
    if (url) {
      el.href = url; el.target = '_blank'; el.rel = 'noopener';
    } else {
      el.href = '#'; el.classList.add('disabled');
    }
  });

  if (!config.previewMode && bookingUrls.all) setupNote.hidden = true;

  const openBooking = type => {
    const url = bookingUrls[type] || bookingUrls.all;
    if (url) { window.open(url, '_blank', 'noopener'); return; }
    dialog.showModal();
  };

  document.querySelectorAll('[data-book]').forEach(btn => {
    btn.addEventListener('click', () => openBooking(btn.dataset.book || 'all'));
  });

  closeBtn.addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', e => {
    const box = dialog.getBoundingClientRect();
    if (e.clientX < box.left || e.clientX > box.right ||
        e.clientY < box.top  || e.clientY > box.bottom) dialog.close();
  });

  // ─── AVAILABILITY FORM ─────────────────────────────────────────────────────
  document.getElementById('availabilityForm').addEventListener('submit', e => {
    e.preventDefault();
    openBooking(document.getElementById('stayChoice').value);
  });

  // ─── GUESTY EMBED ──────────────────────────────────────────────────────────
  const frameWrap = document.getElementById('bookingEngineFrameWrap');
  const frame     = document.getElementById('bookingEngineFrame');
  const preview   = document.getElementById('bookingPreview');

  if (config.bookingEngineEmbedUrl) {
    frame.src       = config.bookingEngineEmbedUrl;
    frameWrap.hidden = false;
    preview.hidden   = true;
  }

  // ─── AIRBNB FALLBACK LINKS ────────────────────────────────────────────────
  const airbnbFallback     = document.getElementById('airbnbFallback');
  const airbnbMidnightBtn  = document.getElementById('airbnbMidnightBtn');
  const airbnbFrontBtn     = document.getElementById('airbnbFrontBtn');
  let showFallback = false;

  if (config.airbnbMidnightUrl) {
    airbnbMidnightBtn.href   = config.airbnbMidnightUrl;
    airbnbMidnightBtn.hidden = false;
    showFallback = true;
  }
  if (config.airbnbFrontUrl) {
    airbnbFrontBtn.href   = config.airbnbFrontUrl;
    airbnbFrontBtn.hidden = false;
    showFallback = true;
  }
  if (showFallback) airbnbFallback.hidden = false;

  // ─── SOCIAL MEDIA ─────────────────────────────────────────────────────────
  const socials = [
    { id: 'instagramLink', statusId: 'instagramStatus', footerId: 'footerInstagram', url: config.instagramUrl, label: 'Follow on Instagram →' },
    { id: 'facebookLink',  statusId: 'facebookStatus',  footerId: 'footerFacebook',  url: config.facebookUrl,  label: 'Follow on Facebook →'  },
    { id: 'linkedinLink',  statusId: 'linkedinStatus',  footerId: null,              url: config.linkedinUrl,  label: 'Follow on LinkedIn →'  },
    { id: 'tiktokLink',    statusId: 'tiktokStatus',    footerId: 'footerTiktok',    url: config.tiktokUrl,    label: 'Follow on TikTok →'    },
  ];

  socials.forEach(({ id, statusId, footerId, url, label }) => {
    const el     = document.getElementById(id);
    const status = document.getElementById(statusId);
    if (!el) return;

    if (url) {
      el.href = url;
      el.target = '_blank';
      el.rel = 'noopener noreferrer';
      el.removeAttribute('aria-disabled');
      if (status) status.textContent = label;

      if (footerId) {
        const footer = document.getElementById(footerId);
        if (footer) { footer.href = url; footer.hidden = false; footer.target = '_blank'; footer.rel = 'noopener noreferrer'; }
      }
    } else if (!config.previewMode) {
      el.hidden = true;
    }
  });

})();
